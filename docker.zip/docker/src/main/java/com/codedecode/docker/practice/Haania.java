package com.codedecode.docker.practice;

public class Haania {

    public static void main(String [] args){
        Long start = System.currentTimeMillis();

        for(int i=0;i<100000000; i++) {

            System.out.println("My name is Haania Fatima");
            System.out.println("I am studying in class 1st C section in St Francis Xaviers Girls High School.");
            Long end = System.currentTimeMillis();
            System.out.println("TIME TAKEN = " + (end - start) + " ms");


        }
        }

}
